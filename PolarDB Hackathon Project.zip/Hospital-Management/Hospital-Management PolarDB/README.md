# Hospital-Management
A hospital management system using nodejs , express , mysql , ejS

First clone or Download the project

Next open command prompt in project folder 

Then type npm install (or you can use command npm update)
import the database file in mysql server
After that type nodemon app (or you can use node app) 

Home
![](screenshot/home.PNG)

Sign Up

![](screenshot/signup.PNG)

Dash Board
![](screenshot/dash.PNG)

Medicine Store

![](screenshot/med.PNG)

Report Generate
![](screenshot/report.PNG)

Add Employee Leave
![](screenshot/leave.PNG)
